Start the vLLM
```sh
start_vllm_with_qwen3vl.sh

```

Go to the BrowserUseScript repo to send the browser-use request


Analyze the info of vllm after you run the browser-use request
```py
python analyze_vllm_browser_use.py
```

